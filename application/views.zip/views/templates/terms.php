<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="<?php echo base_url('favicon.ico'); ?>" type="image/gif">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/_talk.css'); ?>">    
    <script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.min.js'); ?>"></script>        
    <script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.min.js'); ?>"></script>    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="theme-color" content="#cd0000">
    <script type="text/javascript">
    $(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>
<title>Talk Point</title>
</head>
<body   data-spy="scroll" data-target="#inner_app_wrapper_right_home" data-offset="50">