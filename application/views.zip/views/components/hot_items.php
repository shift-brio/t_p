<div class="left-pop">
	<div class="row h-row">
		<div class="col s1 m4 l3"></div>
		<div class="col s1 m4 l6"></div>
		<div class="col s10 m4 l3 hot-posts">
			<div class="hot-posts-head">
				<h6 class="hot-posts-head-title">Trending now</h6>
				<button class="hot-posts-head-tool material-icons">close</button>
			</div>
			<div class="hot-posts-body">								
				<div class="no-items">No items here</div>
			</div>
		</div>
	</div>
</div>