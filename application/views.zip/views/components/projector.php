<div class="projector">
	<div class="projector-loader">
		<div class="project-loader-inner"></div>
	</div>
	<div class="projector-head">
		<div class="projector-tools">
			<div class="projector-tool-box">
				<button class="projector-tool material-icons">arrow_back</button>
				<button class="projector-tool material-icons projector-refresh">refresh</button>
				<button class="projector-tool material-icons right">arrow_forward</button>
			</div>
		</div>
		<div class="right">
			<button class="material-icons projector-close">close</button>
		</div>
		<div class="projector-body">			
			<div id="chart_div" style="width: 100%;min-height:400px;max-height: 800px; margin-top: px;"></div>			
		</div>
	</div>
</div>