<div class="media-player">
	<div class="player-head">
		<div class="head-title">
			<a href="<?php echo base_url(); ?>">
				<img src="<?php echo base_url("logo.png"); ?>" alt="TalkPoint Logo" class="talk-logo">
			</a>
		</div>			
		<div class="right head-tools">
			<button data-position="left" data-tooltip="Close"  class="tooltipped material-icons head-tool close-player">close</button>					
		</div>		
	</div>
	<div class="player-body">
		<div class="player-vid yt-vid">
			<iframe src="" frameborder="0" class="yt-iframe"></iframe>
		</div>			
  </div>
</div><!-- https://www.youtube.com/embed/WrsZw8OfnEY -->