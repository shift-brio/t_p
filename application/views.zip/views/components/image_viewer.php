<div class="image-viewer">	
	<img src="" class="viewed-image">
	<button data-position="left" data-tooltip="Close" class="viewer-closer material-icons tooltipped">
		close
	</button>
</div>