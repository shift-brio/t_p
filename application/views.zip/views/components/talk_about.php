<div class="add-box">
	<?php $this->load->view("components/spen_ad"); ?>
</div>
<div class="more-inf">
	<div class="inf-cat">
		<div class="inf-label t-support">Support&nbsp; </div>
		<di class="inf-val">support@talkpoint.online</di>
	</div>	
	<div class="inf-cat">
		<div class="inf-label">Ads&nbsp;<i class="material-icons">launch</i> </div>
		<di class="inf-val">info@talkpoint.online</di>
	</div>
	<div class="inf-cat">					
		<div class="inf-val"><a>&copy;&nbsp;TalkPoint <?php echo date("Y"); ?></a></div>
	</div>
</div>