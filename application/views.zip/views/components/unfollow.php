<div class="unfollower">
	<div class="row">
		<div class="col s12 m4 l4"></div>
		<div class="col s12 m4 l4">
			<div class="unfollow-writer">
				<button data-tooltip="Cancel" data-position="right" class="unf-cancel clickable tooltipped material-icons">close</button>
				<div class="unf-name">Unfollow 
					<span class="unf-handle" data-removed="" data-user="talkpoin">@talkpoint</span>?
				</div>
				<button data-tooltip="Unfollow" data-position="left" class="unf-go tooltipped clickable">Unfollow</button>
			</div>			
		</div>
		<div class="col s12 m4 l4 unf"></div>
	</div>
</div>