<div class="log-tabs">
	<a href="<?php echo base_url("join"); ?>" class="log-tab">Sign Up</a>
	<button class="log-tab login-toggle">Login</button>
</div>