<div class="talk-ad">
	<a href="https://www.spendtrack.app" target="_blank">
		<div class="talk-ad-head">
			<div class="ad-title">SpendTrack</div>
			<div class="right ad-info">Ad</div>
		</div>
		<div class="ad-body">
			<div class="ad-text">Your income, expenses, accounting, tax and networth solution</div>		
		</div>
	</a>
</div>