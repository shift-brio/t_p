<div class="login-util util-item">
	<div class="login-cont">
		<input value="" placeholder="Email" type="email"class="browser-default u-mail pass-in">
		<input value="" placeholder="Password" type="password" class="browser-default u-pass pass-in"><br><br>
		<a tabindex="1" class="forgot">Forgot password?</a>
	</div>	
	<br>			
	<div class="tools">
		<button class="close-util left util-btn material-icons">close</button>
		<button class="login-btn right util-btn material-icons">lock_open</button>
	</div><br><br>
</div>			
<div class="code-util util-item">
	<div class="change-code">
		<div class="change-pass">
			<input value="" placeholder="Enter email to recover password for" type="email"class="browser-default rec-email pass-in">				
		</div>	
		<br>	
		<div class="tools">	
			<button class="left enter-by util-btn">Enter code</button>				
			<button class="send-code right util-btn">Send</button>
		</div>
		<br><br>
		<div class="divider"></div>
		<br>
	</div>					
	<div class="change-pass rec-change">	
		<input value="" placeholder="Email" type="text"class="browser-default rec-mail_ pass-in">					
		<input value="" placeholder="Enter recovery code" type="text"class="browser-default rec-code pass-in">
		<input  placeholder="New password" type="password"class="browser-default rec-new pass-in">				
	</div><br>		
	<div class="tools">
		<button class="close-util left util-btn material-icons">close</button>
		<button data-position="top" data-tooltip="Change password" class="tooltipped change-password rec-change  right util-btn">Save</button>
		<button data-position="top" data-tooltip="Resend code" class="tooltipped rec-change rec-resend right util-btn">Resend code</button>
	</div><br><br>
</div>