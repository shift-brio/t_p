<button class="material-icons admin-btn btn-floating">supervisor_account</button>
<div class='admin_list'>			    
	 <div class="admin-item">
	 		<i class="material-icons admin-icon">perm_contact_calendar</i>
	 		<div class="admin-text">
	 			Admin portal
	 		</div>
	 </div>
	 <div class="admin-item">
	 		<i class="material-icons green admin-icon">edit</i>
	 		<div class="admin-text">
	 			Editor's portal
	 		</div>
	 </div>
</div>