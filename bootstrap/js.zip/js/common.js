
(function($, window, undefined) {
    //is onprogress supported by browser?
    var hasOnProgress = ("onprogress" in $.ajaxSettings.xhr());

    //If not supported, do nothing
    if (!hasOnProgress) {
        return;
    }
    
    //patch ajax settings to call a progress callback
    var oldXHR = $.ajaxSettings.xhr;
    $.ajaxSettings.xhr = function() {
        var xhr = oldXHR();
        if(xhr instanceof window.XMLHttpRequest) {
            xhr.addEventListener('progress', this.progress, false);
        }
        
        if(xhr.upload) {
            xhr.upload.addEventListener('progress', this.progress, false);
        }
        
        return xhr;
    };
})(jQuery, window);

(function($){

    $.fn.extend({ 

        addTemporaryClass: function(className, duration) {
            var elements = this;
            setTimeout(function() {
                elements.fadeOut("slow");
                elements.attr('class','hidden');
            }, duration);

            return this.each(function() {                
                $(this).addClass(className);                
            });
        }
    });

})(jQuery);

var rmess = setInterval(function(){ r_mess() },10* 1000);
function updateScroll(){
    var element = document.getElementById("msg_cont");
    element.scrollTop = element.scrollHeight;
}
$(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();        
        $("#trends").attr('style','border-radius:3px; margin-top:20px; max-height:200px;  width:320px;overflow-y:auto;background:#fff');                
        rss();
    });
window.twttr = (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0],
        t = window.twttr || {};
      if (d.getElementById(id)) return t;
      js = d.createElement(s);
      js.id = id;
      js.src = "https://platform.twitter.com/widgets.js";
      fjs.parentNode.insertBefore(js, fjs);

      t._e = [];
      t.ready = function(f) {
        t._e.push(f);
      };

      return t;
    }(document, "script", "twitter-wjs"));
(function($){
  $.fn.customerPopup = function (e, intWidth, intHeight, blnResize) { 
    // Prevent default anchor event
    e.preventDefault();
    
    // Set values for window
    intWidth = intWidth || '500';
    intHeight = intHeight || '400';
    strResize = (blnResize ? 'yes' : 'no');

    // Set title and open popup with focus on it
    var strTitle = ((typeof this.attr('title') !== 'undefined') ? this.attr('title') : 'Social Share'),
        strParam = 'width=' + intWidth + ',height=' + intHeight + ',resizable=' + strResize,            
        objWindow = window.open(this.attr('href'), strTitle, strParam).focus();
  }
  
  /* ================================================== */
  
  $(document).ready(function ($) {
    $('.customer.share').on("click", function(e) {
      $(this).customerPopup(e);
    });
  });
    
}(jQuery));
function readURL(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#post_image').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }


 $(document).ready(function(){
        $('[data-toggle="popover"]').popover({html: true,container: 'body'});
 });
 
$(document).ready(function () {
        $("#search_box_post").on('keyup',function () {
            var key = $(this).val();
            $("#loader_image_post").removeClass( "hidden" );
            $.ajax({
                url:$("#post_search_url").val(),
                type:'GET',
                data:'keyword='+key.split("%"),
                success:function (data) {
                    $("#post_result").html(data);
                    $("#post_result").slideDown('fast');
                    $("#loader_image_post").addClass( "hidden" );
                }
            });
        });
    });

$(document).ready(function () {
        $("#search_box").on('keyup',function () {
            var key = $(this).val();
            if (key.length==0) {
                $("#user_result").html('');
            };
            if (key.length>=3) {
            $("#loader_image").removeClass( "hidden" );
            $.ajax({
                url:$("#user_search_url").val(),
                type:'GET',
                data:'keyword='+key,
                success:function (data) {
                    $("#user_result").html(data);
                    $("#user_result").slideDown('fast');
                    $("#loader_image").addClass( "hidden" );
                }
            });
            };
        });
    });
function getComments(id) {
        var div= "add_post_div";
        var p_id=id.value;                
        var main_div=div+p_id;
        var url=$("#get_").val();        
        $.ajax({                
                url:url,
                type:'POST',
                data:{post:p_id},
                success:function (data) {
                 $("#"+main_div).html(data);                 
                }
        });
    }

$(document).ready(function () {        
        $("#edit_toggle").on('click',function () {
            var content=$("#edit_toggle").val();
            if (content=="hidden") {
                $("#edit_div").show();
                $("#edit_toggle").val("not hidden");
                $('#edit_toggle').html("Cancel");
            };
            if (content!="hidden") {
                $("#edit_div").hide();
                $("#edit_toggle").val("hidden")
                $('#edit_toggle').html("Edit Account");
            };           
        });
        
    });
function ajaxRefresh() {
        $("#refresh_span").addClass('spin');      
        $.ajax({
            url: "posts/refresh",
            timeout: 30000,
            success: function (result) {
                $("#feed_content_wrapper").html(result);
                $("#refresh_span").removeClass('spin');
                checkRefresh()
            }                                                
        })
    };
function submitComment(id)
 {
    var id_=id.value;
    var identifier=$("#post_id_comment"+id_).val();   
    var url=$("#url_submit_comment").val();
    var content=$("#comment_textarea"+id_).val();
    if (content!='') {
        $("#loader_image_comm").removeClass( "hidden" );
    $.ajax({
        url:url,
        type:'POST',
        data:{comment_data : content , identifier : identifier},
        success:function (data) {
           getComments(identifier);
           $("#comment_textarea"+id_).val("");
           $("#loader_image_comm").addClass( "hidden" );
           ajaxRefresh();                  
        }
    });
   };
 }
 function count_m()
    {
        var auth="";
        $.ajax({
                url:'messages/r1', 
                type:'POST',
                data:{auth:auth}, 
                success: function (result) {
                  $("#m_count").html(result);
                }
         })     
    }
 function loadNet() {
        count_m();
        $.ajax({
            url: "user/loadNetworks", 
            success: (function (result) {
                $("#circles_wrapper").html(result);

            })
        })
    };
    loadNet(); 
    setInterval(loadNet, (20* 1000));
function transfer(id){
    $("#postsCountry").modal('hide');
    var id_=id.value;
    $("#delete_btn").val(id_);
 }
function deletePost(id){
    var id_=id.value;
    var url_=$("#btn_didmiss").val();
    $("#loader_delete").removeClass('hidden');
    $.ajax({
            url:url_, 
            type:'POST',
            data:{identifier:id_}, 
            success: function (result) {
                $("#deletePost").modal('hide');
                ajaxRefresh();
                $("#loader_delete").addClass('hidden');
            }
        })
    };
function transferpost(id){
    var id_=id.value;
    $("#postsCountry").modal('hide');
    $("#repost_btn").val(id_);
}
function repostPost(id){
    var id_=id.value;
    var url_=$("#btn_didmiss_repost").val();
    $("#loader_repost").removeClass('hidden');
    $.ajax({
            url:url_, 
            type:'POST',
            data:{identifier:id_}, 
            success: function (result) {
                $("#repostPost").modal('hide');
                ajaxRefresh();
                $("#loader_repost").addClass('hidden');
            }
        })
    };
function checkRefresh(){
    var thisdata="";
    $.ajax({
            url:'posts/cr_', 
            type:'POST',
            data:{time:thisdata}, 
            success: function (result) {
                if (result=='true') {
                    $("#not").attr('style','float:left;height:4px;width:4px; background:red;');
                };
                if (result=='false') {
                    $("#not").attr('style','float:left;height:4px;width:4px; background:transparent;');
                };
            }
        })
    };
checkRefresh(); 
setInterval(checkRefresh, (10* 1000));
$(document).ready(function () {
        $("body").on('click',function () {
            var state="";
            $.ajax({
                url:$("#this").val(),
                type:'POST',                
            });
        });
    });
function cofirm(id){
    var u_id=id.value;
    $("#loader_image"+u_id).removeClass('hidden');
    $.ajax({
            url:'user/ca_', 
            type:'POST',
            data:{u_id:u_id}, 
            success: function (result) {
              $("#loader_image"+u_id).addClass('hidden');
              $("#"+u_id).hide();
              loadNet();
              r_c()
              //$("#c_t").click
            }
        })
};
function r_c(){
    var num="";
    $.ajax({
            url:'user/r_c', 
            type:'POST',
            data:{num:num}, 
            success: function (result) { 
            $("#c_d").html(result);
            console.log(result);          
            }
        })
    };
r_c(); 
setInterval(r_c, (3600* 1000));
$(document).ready(function () {
        $("body").on('click',function () {
            var state="";
            $.ajax({
                url:"user/this",
                type:'POST',                
            });
        });
    });
function getComments_c(id) {
        var div= "add_post_div_c";
        var p_id=id.value;                
        var main_div=div+p_id;
        var url=$("#get_").val();        
        $.ajax({                
                url:'posts/get_comments_c',
                type:'POST',
                data:{post:p_id},
                success:function (data) {
                 $("#"+main_div).html(data);                 
                }
        });
 }
function submitComment_c(id)
 {
    $("#comment_button1").click(); 
    var id_=id.value;
    var identifier=$("#post_id_comment"+id_).val();   
    var url=$("#url_submit_comment").val();
    var content=$("#comment_textarea"+id_).val();
    if (content!='') {
        $("#loader_image_comm").removeClass( "hidden" );
    $.ajax({
        url:url,
        type:'POST',
        data:{comment_data : content , identifier : identifier},
        success:function (data) {           
           $("#comment_textarea"+id_).val("");
           $("#loader_image_comm").addClass( "hidden" );
           $("#comment_button1").click();            
        }
    });
   };
 }
function countryFeed(country){
    var locale=country.value;
    var url_=$("#viewposts_btn").val();
    var p="";
    $.ajax({
            url:url_, 
            type:'POST',
            data:{locale:locale,p:p}, 
            success: function (result) {
                if (result!='') {
                $("#loader_country").addClass('hidden');
                $("#country_feed").html(result);
                };
                if (result=='') {
                 $("#loader_country").addClass('hidden');
                $("#country_feed").html('No posts here');
                };
            }
        })
    };
$(document).ready(function () {
        $("#viewposts_btn").on('click',function () {
        var country=$("#country").val();
        var url_=$("#viewposts_btn").val();
        var p="";
        $("#loader_country").removeClass('hidden');
        $("#selectCountry").modal('hide');                                      
        $("#postsCountry").modal('show');
        $.ajax({
            url:url_, 
            type:'POST',
            data:{locale:country,p:p}, 
            success: function (result) {
                $("#loader_country").addClass('hidden');
                $("#country_feed").html(result);
            }
        })                                                              
        });
});

function r_mess()
        {
         var auth="";  
         var id = $("#close_chat").val();
          if (id!='') {
            $.ajax({
                url:'user/chat', 
                type:'POST',
                data:{uid:id}, 
                success: function (result) {                  
                  $("#cont_chat").html(result);                  
                  $.ajax({
                    url:'messages/r', 
                    type:'POST',
                    data:{user:id,auth:auth}, 
                    success: function (result) {
                      $("#m_count").html(result);
                      loadNet();
                    }
                 })  
                }
         })
          };
}
function read(id) {
        var id_=id.value;
        if (id_!='') {
        var auth="";                
        $("#close_chat").attr('value',id_);
        $("#chat_").fadeIn('slow');
        $("#chat_").removeClass('hidden');
        $("#loader_chat").removeClass('hidden');        
        $.ajax({
                url:'user/chat', 
                type:'POST',
                data:{uid:id_}, 
                success: function (result) {
                  $("#loader_chat").addClass('hidden');
                  $("#cont_chat").html(result);
                  r_mess(); 
                  updateScroll()
                setInterval(r_mess, (10* 1000));
                }
         })
          $.ajax({
            url:'messages/r', 
            type:'POST',
            data:{user:id_,auth:auth}, 
            success: function (result) {
              $("#m_count").html(result);
              loadNet();
            }
         })       
        };
};
function send()
{
    var auth="";
    var message = $("input#search_box_pos").prop("value");    
    var to =$("#close_chat").val();
    if (message!='') {
        $.ajax({
            url:'messages/sm', 
            type:'POST',
            data:{message:message,to:to}, 
            success: function (result) {                
              $("#loader_chat").removeClass('hidden');
                $.ajax({
                    url:'user/chat', 
                    type:'POST',
                    data:{uid:to}, 
                    success: function (result) {
                      $("#loader_chat").addClass('hidden');
                      $("#cont_chat").html(result);
                       updateScroll() 
                       $('input#search_box_pos').val('');                                
                    }
                 })
            $.ajax({
                url:'messages/r', 
                type:'POST',
                data:{user:to,auth:auth}, 
                success: function (result) {
                  $("#m_count").html(result);
                }
             })             
            }
         })   
    };

}
function close_chat(){    
    $("#chat_").fadeOut("slow"); 
    $("#cont_chat").html('');
    $("#close_chat").attr('value','');
    $("#loader_chat").removeClass('hidden');
    clearInterval(rmess);
};
 $(document).ready(function () {
        $("input#search_box_pos").on('keyup',function () {
            $("input#search_box_pos").val($(this).val());
        });
    });
$(document).ready(function () {
        $("input#search_box_pos").on('keypress',function (e) {
             if(e.which == 13) {
                send()                               
             }           
        });
});
function chats()
{
    var auth="";
    $.ajax({
        url:'messages/cunt', 
        type:'POST',
        data:{auth:auth}, 
        success: function (result) {
          $("#m_count").html(result);
          loadNet()
        }
     })    
} 
function load_reply(id)
{
    var comment_id=id.value;
    var auth="";
    $("#loader_comment_reply").removeClass('hidden');
    $.ajax({
        url:'posts/r_com', 
        type:'POST',
        data:{auth:auth,comment_id:comment_id}, 
        success: function (result) {
          $("#reply_comment_div"+comment_id).html(result);
          $("#loader_comment_reply").addClass('hidden');
        }
     })    
}
function submitReply(id)
{
    var comment_id=id.value;    
    var reply= $("#reply_textarea"+comment_id).val();
    var auth ="";
    $.ajax({
        url:'posts/r_comm', 
        type:'POST',
        data:{auth:auth,comment_id:comment_id,reply:reply}, 
        success: function (result) {
          $("#reply_comment_div"+comment_id).html(result);
         $.ajax({
            url:'posts/c_c', 
            type:'POST',
            data:{auth:auth,comment_id:comment_id}, 
            success: function (result) {
              $("#reply_counter"+comment_id).html(result);
            }
         })  
        }
     })    
}
function c_reply(id){
    var comment_id=id.value;
    alert(comment_id);
    var auth="";
    $.ajax({
        url:'posts/c_c', 
        type:'POST',
        data:{auth:auth,comment_id:comment_id}, 
        success: function (result) {
          $("#reply_counter"+comment_id).html(result);
        }
     })  
}

function closeRequests()
{
    $("#c_t").click();
}
function viewpost(id)
{
    var identifier=id.value;
    var auth = "";
    $("#viewPost").modal('show');
    $.ajax({
        url:'posts/get_post', 
        type:'POST',
        data:{auth:auth,identifier:identifier}, 
        success: function (result) {          
          $("#post_view").html(result);
        }
     })  
}
function close_m(modal)
{
    var modal =modal.value;
    $("#"+modal).modal('hide');
}

function clear_file()
{    
    var input = $("#post_attach");
    input.replaceWith(input.val('').clone(true));
}

function submitPost()
         {   
            $("#post_err").html('');
            var title=$("#tittle").val();
            var content=$("#post_textarea").val();
            var table=$("#sel1").val();         
            var data = new FormData();
            if (title==''||title==' ') {
                $("#post_err").html('Enter post title');
            };            
            
            if (title!=''&&title!=' ') {
            if ($("#input#post_attach").val()!='') {
            $("#mainprogress").removeClass('hidden');
            jQuery.each(jQuery('input#post_attach')[0].files, function(i, file) {
            data.append('file-'+i, file);
              });
            };
            data.append('title', title);
            data.append('content', content);
            data.append('table', table);                                                 
            $.ajax({
                url:'posts/add_post',
                type:'POST',
                data:data,
                contentType: false,       
                cache: false,             
                processData:false,
                progress: function(e) {
                    if(e.lengthComputable) {
                        var pct = (e.loaded / e.total) * 100 + '%';
                        $("#innerprogress").attr('style','width:'+pct+';')
                    }
                    else {
                        $("#mainprogress").addClass('hidden');
                    }
                },
                 success:function (data) {
                    if (data.length>100) {  
                    $("#post_err").html("An unknown error occurred with the uploaded file");
                    $("#mainprogress").addClass('hidden');
                    $("#innerprogress").attr('style','width:;')                    
                    };
                    if (data.length<100) {  
                    $("#post_err").html(data);
                    $("#mainprogress").addClass('hidden');
                    $("#innerprogress").attr('style','width:;')                    
                    };    
                    if (data=='') {
                        ajaxRefresh();
                        $("#mainprogress").addClass('hidden');
                        $("#innerprogress").attr('style','width:;')
                        $("#tittle").val('');
                        $("#post_textarea").val('');
                        clear_file();
                        $("#posted_div").addTemporaryClass("unhidden", 5000);
                    };                 
                }               
            });                   

            };
         }

function like(identifier)
{
    var identifier=identifier.value;
    var auth="";
    if (identifier!='') {
    $.ajax({
        url:'posts/ls', 
        type:'POST',
        data:{auth:auth,identifier:identifier}, 
        success: function (result) {          
          if (result=='like_exist') {
            $.ajax({
                url:'posts/dl', 
                type:'POST',
                data:{auth:auth,identifier:identifier}, 
                success: function (result) {          
                  $("#likes_btn"+identifier).attr('style','background:none; border:none; float:left; color:#d9d9d9; font-size:1.3em;');
                  $.ajax({
                    url:'posts/lc', 
                    type:'POST',
                    data:{auth:auth,identifier:identifier}, 
                    success: function (result) {          
                      $("#likes"+identifier).html(result);
                    }
                 }) 
                }
             }) 
          };
          if (result=='liked') {
            $("#likes_btn"+identifier).attr('style','background:none; border:none; float:left; color:#cd0000; font-size:1.3em;');
            $.ajax({
                url:'posts/lc', 
                type:'POST',
                data:{auth:auth,identifier:identifier}, 
                success: function (result) {          
                  $("#likes"+identifier).html(result);
                }
             }) 
          };
        }
     })  
    };
}

function transfer_edit(id){
    if ($("#edit_textarea").val()!='') {
        $("#edit_textarea").val('');
         var id_=id.value;
        $("#save_btn").val(id_);
        var content=$("div.post"+id_).html();
        var content=content.replace('/<br>/', '');
        $("#edit_textarea").val(content);        
    };  
    if ($("#edit_textarea").val()=='') {
        var id_=id.value;
        $("#save_btn").val(id_);
        var content=$("div.post"+id_).html();
        var content=content.replace('/<br>/', '');
        $("#edit_textarea").val(content);
    }; 
 }

 function saveEdit(id){
    var id_=id.value;
    var url_=$("#btn_didmiss_save").val();
    var content=$("#edit_textarea").val(); 
    $("#loader_edit").removeClass('hidden');
    $.ajax({
            url:url_, 
            type:'POST',
            data:{identifier:id_,content:content}, 
            success: function (result) {
                $("#editPost").modal('hide');
                ajaxRefresh();
                $("#loader_edit").addClass('hidden');
            }
        })
    };
function more(url)
{
    var url=url.value;
    $("#more_view").html("<?php echo file_get_contents('"+ url +"'); ?>");
}
function loadRss(){
    $("#rss_view").html(''); 
    var source=$("#source_name").val();
    $("#loader_rss").removeClass('hidden');
    $.ajax({
            url:'posts/gr', 
            type:'POST',
            data:{source:source}, 
            success: function (result) {
                $("#loader_rss").addClass('hidden'); 
                $("#rss_view").html(result);                
            }
    })
}
function rss(){    
    var source="std";        
    $.ajax({
            url:'posts/gr', 
            type:'POST',
            data:{source:source}, 
            success: function (result) {
                var source="nyt";
                $.ajax({
                        url:'posts/gr', 
                        type:'POST',
                        data:{source:source}, 
                        success: function (result) {                           
                        }
                    })
            }
        })
    };