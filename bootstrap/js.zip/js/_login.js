var timeFormat = function(seconds) {
  var m = Math.floor(seconds / 60) < 10 ? "0" + Math.floor(seconds / 60) : Math.floor(seconds / 60);
  var s = Math.floor(seconds - (m * 60)) < 10 ? "0" + Math.floor(seconds - (m * 60)) : Math.floor(seconds - (m * 60));
  return m + ":" + s;
};
$("#trends").attr('style', 'border-radius:3px;');
$(document).ready(function() {
  $('[data-toggle="tooltip"]').tooltip();
  $("#trends_wrapper").attr('style', 'border-radius:3px; margin-top:20px; max-height:200px;  width:320px;overflow-y:auto;background:#fff');
});

function getComments(id) {
  var div = "post";
  var p_id = id.value;
  var main_div = div + p_id;
  var url = $("#get_").val();
  $.ajax({
    url: url,
    type: 'POST',
    data: {
      post: p_id
    },
    success: function(data) {
      $("#" + main_div).html(data);
    }
  });
}
$(window).scroll(function(){
    if ($(window).scrollTop() + $(window).height() == $(document).height() - 0 ) {
        var count = $("._lta").val()
        var curr = $(".post_search").attr("data-curr")
        //refresh_page(5,curr);     
     }
})

function l_y(id)
{
var loader = $(".comm-loader")
var c_id=id.value;
var auth="";        
if (!$("#r_cd"+c_id).hasClass("in")) {
    loader.removeClass('hidden');
    $.ajax({
        url:'posts/r_com', 
        type:'POST',        
        data:{auth:auth,c_id:c_id}, 
        success: function (result) {
          loader.addClass('hidden');
          if (result.status != false) {
              $("#r_cd"+c_id).html(result.m);                  
            }
        },
        error:function(){
            loader.addClass('hidden');
        }
     })  
}  
}
$(document).ready(()=>{
    more_func();
})
more_func = function(){
    $(".more-text").each(function(){
        $(this).click(function(){               
            $(this).parent().parent().parent().removeClass("less");
            $(this).parent().parent().remove();
        })
    })
}
$(document).ready(function() {  
  $("#smsi").on('click', function() {
    $(".emt").removeClass("emt");
    var f_name = $("#first_name").val();
    var l_name = $("#last_name").val();
    var names = $("#username").val();
    var email = $("#address").val();
    var password = $("#password").val();
    var password_confirm = $("#pass").val();
    var year = $("#year").val();
    var agree = $(".agree-in").val();

    if (f_name == '' || f_name.replace(/\s/g, '').length < 2) {
       $("#first_name").addClass("emt");
    }

    if (l_name == '' || l_name.replace(/\s/g, '').length < 2) {
      $("#last_name").addClass("emt");
    }
    if (names == '' || names.replace(/\s/g, '').length < 2) {
      $("#username").addClass("emt");
    }

    function validateEmail(email) {
      var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(email);
    }
    if (email == '' || email.replace(/\s/g, '').length < 2) {
      $("#address").addClass("emt");
    };
    if (password.replace(/\s/g, '').length < 4) {
      $("#password").addClass("emt");
      alert("Enter a valid password of not less that 4 characters")
    }
    if (agree != 'on') {
      $(".check-agree").attr('style', 'color:#cd0000; !important')
    } else {
      $(".check-agree").attr('style', 'color:green;')
    }
    if (f_name != '' && agree == 'on' && year != '--birth year--' && f_name.replace(/\s/g, '').length > 2 || l_name != '' && l_name.replace(/\s/g, '').length > 2 || names != '' && names.replace(/\s/g, '').length > 2 && validateEmail(email)) {
      
    }
    var country = $("#country").val();
    if (country == "--select country--") {
      $("#country").attr('style', "border:1px solid #cd0000 !important;")
    };
    if (year == '--birth year--') {
      $("#year").attr('style', "border:1px solid #cd0000 !important;")
    };    
    if (f_name != '' && agree == 'on' && year != '--birth year--' && country != "--select country--" && f_name.replace(/\s/g, '').length > 2 && l_name.replace(/\s/g, '').length > 2  && names.replace(/\s/g, '').length > 2 && validateEmail(email) && password == password_confirm) {
      $("#lmis").show();      
      var form = jQuery(this).serializeArray();
      var pass = $("#password").val();
      $.ajax({
        url: $("#sign_up_url").val(),
        type: 'POST',
        data: {
          year: year,
          country: country,
          firstName: f_name,
          lastName: l_name,
          userName: names,
          email: email,
          password: pass
        },
        success: function(data) {
          if (data.status == true) {
            location.reload();
            $("#loader_image_sign_after").hide();
          }
          else{            
            alert(data.m)
            if (data.m.lengh == '47') {
              $("#address").attr('style', "color:#cd0000; border-color:#cd0000;");
            }
          }
          $("#lmis").hide();
        }
      });
    };
  });

});
$(document).ready(function() {
  base_url = $(".main-url").val()
  setTimeout(function(){
    load_pop();
    load_trend();
  },1000)
  $("#pass").on('keyup', function() {
    if ($("#password").val() != $("#pass").val() && $("#password").val() != '') {
      $("#pass").attr('style', "color:#cd0000;");
      $("#confirm_ok").hide();
    };
    if ($("#password").val() == $("#pass").val() && $("#password").val() != '') {
      $("#pass").attr('style', "color:green;");
      $("#confirm_ok").show();
    };
  });
});
load_pop = function(){
    $.ajax({
        url:base_url+"getPopular",
        type:"POST",
        success:function(response){
            $(".pop-div").html(response.m);
        }
    })
}
load_trend = function(){
    $.ajax({
        url:base_url+"getTrends",
        type:"POST",
        success:function(response){
            $(".trend-div").html(response.m);
        }
    })
}
$(document).ready(function() {
  $(".si_rec").click(function(){
    alert($("div.remd").html())
  })
  $("#password").on('keyup', function() {
    if ($("#password").val() != $("#pass").val() && $("#password").val() != '') {
      $("#pass").attr('style', "color:#cd0000;");
      $("#confirm_ok").hide();
    };
    if ($("#password").val() == $("#pass").val() && $("#password").val() != '') {
      $("#pass").attr('style', "color:green;");
      $("#confirm_ok").show();
    };
  });
});
$(document).ready(function() {
  $("#address").on('keyup', function() {
    var email = $("#address").val();

    function validateEmail(email) {
      var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(email);
    }
    if (!validateEmail(email)) {
      $("#address").attr('style', "color:#cd0000;");
    };
    if (validateEmail(email)) {
      $("#address").attr('style', "color:;");
    };
  });
});
$(document).ready(function() {
  $("#address").on('click', function() {
    var email = $("#address").val();
    if (email == "Field cannot be empty") {
      $("#address").val("");
    };
  });
});

$(document).ready(function() {
  $("button#btn_submit").on('click', function() {
    var email = $("input#login_email").val();
    var pass = $("input#login_password").val();
    if (email == '' && pass != '') {
      alert("Enter your email  address");
    };
    if (pass == '' && email != '') {
      alert("Enter your password");
    };
    if (email == '' && pass == '') {
      alert("Enter your email  address And Password");
    };
    if (pass != '' && email != '') {
      $(".main-loader").removeClass('hidden');
      $.ajax({
        url: $("input#login_url").val(),
        type: 'POST',
        data: {
          email: email,
          password: pass
        },
        success: function(data) {
          if (data == "denied") {
            $(".main-loader").addClass('hidden');
            alert("Invalid username or password");
          };
          if (data == "granted") {
            $(".main-loader").addClass('hidden');
            location.reload();
          }
        }
      });
    };
  });
});

function share() {
  var table = $("#sel1").val();
  var title = $("#share_title").val();
  var image = $("#share_image").val();
  var content = $("#post_textarea_share").val();
  var auth = "";
  if (title != '') {
    $("#loader_share").removeClass("hidden");
    $.ajax({
      url: 'share/send',
      type: 'POST',
      data: {
        table: table,
        title: title,
        image: image,
        content: content,
        auth: auth
      },
      success: function(data) {
        $("#loader_share").addClass("hidden");
        window.close();
      }
    });
  };
}
$(document).ready(function() {
  $(".copy_link").click(function(){
      var l = $(".p-link");
      l.select();
      document.execCommand("copy");
  })
  $("#login_password").on('keypress', function(e) {
    if (e.which == 13) {
      $("#btn_submit").click();
    }
  });
});

function viewpost(id) {
  var identifier = id.value;
  var auth = "";
  $("#viewPost").modal('show');
  $.ajax({
    url: 'posts/get_post',
    type: 'POST',
    data: {
      auth: auth,
      identifier: identifier
    },
    success: function(result) {
      $("#post_view").html(result);
    }
  })
}

function close_m(modal) {
  var modal = modal.value;
  $("#" + modal).modal('hide');
}

function load_page() {
  $("#" + $(".page-holder").val()).removeClass('active')
  var pager = $("#" + $(".page-holder").val()).attr('value');
  var page = 'country'
  $(".main-loader").show()
  var country = $("#country_pager").val()
  if ($(".page-holder").val() != 'feeds_pager') {
    $.ajax({
      url: "posts/load",
      type: "POST",
      data: {
        page: page,
        country: country,
        pager: pager
      },
      success: function(data) {
        if (data == '') {
          $(".main-loader").hide()
          $("#selectCountry").modal('hide')
          $("input.mouseover").val('1')
        } else {
          $(".main-loader").hide()
          $(".page-content-wrapper").html(data)
          $("#selectCountry").modal('hide')
          more_func();
        }
      },
      error: function() {
        $(".main-loader").hide()
        $("#selectCountry").modal('hide')
      }
    })
  } else {
    $(".main-loader").hide()
    $("#selectCountry").modal('hide')
  }
}

$(document).ready(function () {             
      $("#pager,#pager1,#pager2,#pager3,#pager4,#pager5,#pager6,#pager7,#pager8,#pager9,#feeds_pager").on('click',function () {
      var page = $(".page-holder").val()
      $(".active").removeClass("active")
      $("#"+page).removeClass('active')
      $(this).addClass('active')
      $(".page-holder").val($(this).attr('id'))
      var to = $(this).attr('value');
      $(".main-loader").show()
      if (to == 'feeds') {
          u = "getFeeds";
      }else{
          u = "getColFeeds";
      }
      if ($(this).attr('id') == 'viewposts_btn') {
          var country = $("#country_pager").val()
      }        
      else{
          var country = '';
          $.ajax({
              url:u,
              type:"POST",
              data:{col:to},
              complete:function(){
                  $(".main-loader").hide()
              },
              success:function(data){                                        
                  if (data.status) {
                      if (data.m.length > 0) {
                          $(".page-content-wrapper").html("");
                          $('html, body').animate({scrollTop:0}, 1000);
                          $(".tvd").val('');
                          $("input.mouseover").attr('value',1); 
                          for (var i = 0; i < data.m.length; i++) {                                                               
                              $(".page-content-wrapper").append(data.m[i].data);                                
                          }
                      }
                      $(".post_search").attr("data-curr",data.curr_sub);                        
                  }else{
                      if ($(".n-post").length > 0) {

                      } else{
                          $(".page-content-wrapper").html(data.no);
                      } 
                  }
                  more_func();
              },
              error:function(){
                  alert("Internet error, check your connection")
              }
          })
      }
  });
});
function refresh_page(l = false,curr = false){
    var pag = $(".page-holder").val()
    var to  = $("#"+pag).attr("value")
    if (l != false) {
        l = l;
    }
    else{
        l = 'not';
    }
    if (l != 'not') {
        $(".fetch-loader").show()
    }
    else{
        $(".main-loader").show()
    }
    if (to == 'feeds') {
        u = "getFeeds";
    }else{
        u = "getColFeeds";
    }                                                           
    $(".btn-spin").addClass("spin")
    $.ajax({
        url:u,
        type:"POST",
        data:{col:to,limit:l,curr:curr},
        complete:function(){
            $(".main-loader").hide()
            $(".btn-spin").removeClass("spin")
        },
        success:function(data){
            if (data.status) {
                if (data.m.length > 0) {
                    $(".page-content-wrapper").html("");                    
                    $("input.mouseover").attr('value',1)
                    $(".tvd").val(''); 
                    for (var i = 0; i < data.m.length; i++) {                                                               
                        $(".page-content-wrapper").append(data.m[i].data);
                    }
                }
            }else{
                if ($(".n-post").length > 0) {

                } else{
                    $(".page-content-wrapper").append(data.no);
                }                    
            }           
        },
        error:function(){
            
        }
    })
}
function alert(t = false){
    if(t != false){
      $(".alt-text").html(t)
    }
    $(".alt").show('fast')
    $(".alt-bx").show('fast')
}
$(document).on('mouseover', function() {
  var count = $("input.mouseover").val()
  if (count < 10) {
    $("input.mouseover").attr('value', +2 + +count)
  }
  if (count < 3) {
    //other         
    $(".p_sin").each(function() {
      $(this).click(function() {
        id = $(this).attr('value');
        f_com(id, 'posts')
      })
    })
    $(".link-share").each(function(){
        $(this).click(function(){
            var link = $(this).attr("data-src")
            $(".p-link").val(link);
        })
    })
   $(".progress").each(function() {
        $(this).on("click",function(e){
          var id = $(this).attr("id");
          var w = e.offsetX / $(this).width() * 100;
          var v = document.getElementById("vid"+id);
           var duration = v.duration;                        
           if (w > 100)
            w = 100;
           var cur = (duration * w)/100
           $(this).children(".progress-bar").attr("style","width:"+w+"%;");
           $(this).children(".m_m").title = Math.round(w); 
           v.currentTime = cur;       
        });        
    });
    $(".media-progress").each(function() {        
        var id = $(this).attr("id");        
        var v = document.getElementById("vid"+id);
        $(".drag").attr("style","width:"+ v.volume * 100 +"%;");        
    });
    $(".v_pl").each(function() {   
        var id = $(this).attr("value");  
        var v = document.getElementById("vid"+id);   
        $(this).on("mouseover",function(){           
          $(".vpl-p"+id).fadeIn("slow")
        })
        $(this).on("mouseleave",function(){
          var btn = $(".play-pause"+id);
          if(btn.hasClass('paused')){
            $(".vpl-p"+id).fadeOut("slow")
          }
        })
        $(".rpt"+id).on("click",function(){
          if ($(this).attr("value") == 'off') {
            v.loop = false;           
            $(this).attr("value","on")        
          }
          else{               
            v.loop = true;              
            $(this).attr("value","off")         
          }
        })
        w = $(".vid"+id).attr("volume")*100;
        $(".drag"+id).attr("style","width:"+w+"%;");            
          v.volume = w/100;             
    });    
    $(".player").each(function() {
    $(this).mousedown(function(e){ 
      var id = $(this).attr("value");            
      if( e.button == 2 ) { 
        $(".sto"+id).click()        
        return false; 
      } 
      return true; 
   });
  });
    $(".video").each(function() {        
       $(this).on("right-click",function(){
        //alert("right")
       })
    });
    $(".v-control").each(function() {
        $(this).on("click",function(e){
          var id = $(this).attr("value");
          var w = e.offsetX / $(this).width() * 100;
          var v = document.getElementById("vid"+id);                       
           if (w > 100)
            w = 100;          
            $(".drag"+id).attr("style","width:"+w+"%;");            
            v.volume = w/100;                       
        });        
    });
    $(".player").each(function() {
      var id = $(this).attr("value");
        $(".vid"+id).on("click",function(e){          
              //tp(id)                 
        });        
    });
      //main
    var lesstext = "less";
    var moretext = "... more";

    $(".morelink").each(function() {
      $(this).click(function() {
        var lesstext = "less";
        var moretext = "...See More";
        var id = $(this).attr("value")
        if ($(this).hasClass("less")) {
          $(this).removeClass("less");
          $(this).html(lesstext);
          $("#span" + id).removeClass("hidden");
        } else {
          $(this).addClass("less");
          $(this).html(moretext);
          $("#span" + id).addClass("hidden");
        }
      })
    });
  };
});

function adds() {
  var auth = "";
  $.ajax({
    url: "adds/load",
    type: "POST",
    data: {
      auth: auth
    },
    success: (function(result) {
      $(".add-wrapper").html(result);

    })
  })
};
adds();
setInterval(adds, (30 * 1000));

function vp(post) {
  var v = document.getElementById("vid" + post);
  inner = $(".buffer" + post);
  main = $(".vid-progress" + post);
  var b = Math.floor((v.buffered / v.duration) * 100);
  v.addEventListener("timeupdate", function() {
    if (!isNaN(this.duration)) {
      var width = Math.floor((v.currentTime / v.duration) * 100);
      main.attr("style", "width:" + width + "%");
      var r = v.currentTime;
      var t = v.duration;
      $(".t_count" + post).html(timeFormat(r) + "/" + timeFormat(t));
    }
    var btn = $(".play-pause" + post);
    if (v.ended) {
      btn.attr("title", 'play');
      btn.addClass("glyphicon-play");
      btn.addClass("stopped");
      btn.removeClass("glyphicon-pause");
      btn.removeClass("playing");
      btn.removeClass("paused");
    };
  });
  v.addEventListener("progress", function() {
    if (!isNaN(this.duration)) {
      var range = 0;
      var bf = this.buffered;
      var time = this.currentTime;

      while (!(bf.start(range) <= time && time <= bf.end(range))) {
        range += 1;
      }
      var bs = bf.start(range) / this.duration;
      var be = bf.end(range) / this.duration;
      var b = be - bs;
      inner.attr("style", "width:" + b * 100 + "%");
    }
  });
}

function tp(id) {
  if (id.length > 30) {
    var post = id
  } else {
    var post = id.value
  }
  var btn = $(".play-pause" + post);
  vid = $('.vid' + post);
  var v = document.getElementById("vid" + post);
  var tvd = $(".tvd").val();
  v.addEventListener('timeupdate', vp(post), true);
  if (btn.hasClass("playing") || btn.hasClass("stopped")) {
    btn.attr("title", 'play');
    btn.removeClass("glyphicon-play");
    btn.removeClass("stopped");
    btn.addClass("glyphicon-pause");
    btn.removeClass("playing");
    btn.addClass("paused");
    if (tvd != "" && tvd != post) {
      var v = document.getElementById("vid" + tvd);
      var btn = $(".play-pause" + tvd);
      $('.vid' + tvd).get(0).pause()
      btn.addClass("playing");
      btn.removeClass("paused");
      btn.attr("title", 'play');
      btn.addClass("glyphicon-play");
      btn.removeClass("glyphicon-pause");
    };
    vid.get(0).play()
    $(".tvd").val(post)
  } else {
    btn.addClass("playing");
    btn.removeClass("paused");
    btn.attr("title", 'pause');
    btn.addClass("glyphicon-play");
    btn.removeClass("glyphicon-pause");
    vid.get(0).pause()
    vp(post)
  }
}

function menus(setting) {
  setting = setting.value
  var set = $(".setting" + setting);
  if (set.hasClass('faded')) {
    set.fadeIn("slow")
    set.removeClass('faded')
  } else {
    set.fadeOut("slow")
    set.addClass('faded')
  }
}

function t_c(vid) {
  var post = vid.value
  var vid = document.getElementById("vid" + post);
  if (vid.requestFullscreen) {
    vid.requestFullscreen();
  } else if (vid.mozRequestFullScreen) {
    vid.mozRequestFullScreen();
  } else if (vid.webkitRequestFullscreen) {
    vid.webkitRequestFullscreen();
  }
}

function tc(control) {
  var control = $(".player-controls" + control);
  control.removeClass("hidden")
  alert(control)
}

function rc(control) {
  var control = $(".player-controls" + control);
  control.addClass("hidden");
}

function m(mt) {
  var post = mt.value
  var v = document.getElementById("vid" + post);
  vid = $('.vid' + post);
  var btn = $(".mute" + post);
  if (btn.hasClass("high")) {
    btn.addClass("low")
    btn.attr("title", "unmute");
    btn.removeClass("high")
    btn.removeClass("glyphicon-volume-up")
    btn.addClass("glyphicon-volume-off")
    vid.prop('muted', true);
  } else {
    btn.removeClass("low")
    btn.addClass("high")
    btn.attr("title", "mute");
    btn.removeClass("glyphicon-volume-off")
    btn.addClass("glyphicon-volume-up")
    vid.prop('muted', false)
  }
}
$(document).ready(function() {
  $('[data-dismiss="alt"]').click(function(){
      $(".alt").fadeOut('fast');      
    })
  $(".agree-in").on('click', function() {
    if ($(this).attr('value') == '') {
      $(this).attr('value', 'on');
      $(".check-agree").attr('style', 'color:green;')
    } else {
      $(this).attr('value', '');
      $(".check-agree").attr('style', 'color:#cd0000;')
    }
  })
})
