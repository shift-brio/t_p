$(document).ready(function(){
			$('[data-toggle="popover"]').popover({html: true,container: 'body'});
		});
		$(document).ready(function(){
			$('[data-toggle="tooltip"]').tooltip();
		});
		function state() {
			$.ajax({
				url: $("#fetch").val(), 
				success: (function (result) {
					$("#feeds_content_wrapper").html(result);
				})
			})
		};
		state(); 
		setInterval(state, (120* 1000));
		function transferpost(id){
			var id_=id.value;
			$("#repost_btn").val(id_);
		}
		function repostPost(id){
			var id_=id.value;
			var url_=$("#btn_didmiss_repost").val();
			$("#loader_repost").removeClass('hidden');
			$.ajax({
				url:url_, 
				type:'POST',
				data:{identifier:id_}, 
				success: function (result) {
					$("#repostPost").modal('hide');
					ajaxRefresh();
					$("#loader_repost").addClass('hidden');
				}
			})
		};
		function getComments(id) {
			var div= "add_post_div";
			var p_id=id.value;                
			var main_div=div+p_id;
			var url=$("#get_").val();        
			$.ajax({                
				url:url,
				type:'POST',
				data:{post:p_id},
				success:function (data) {
					$("#"+main_div).html(data);                 
				}
			});
		}
		function submitComment(id)
		{
			var id_=id.value;
			var identifier=$("#post_id_comment"+id_).val();   
			var url=$("#url_submit_comment").val();
			var content=$("#comment_textarea"+id_).val();
			if (content!='') {
				$("#loader_image_comm").removeClass( "hidden" );
				$.ajax({
					url:url,
					type:'POST',
					data:{comment_data : content , identifier : identifier},
					success:function (data) {
						getComments(identifier);
						$("#comment_textarea"+id_).val("");
						$("#loader_image_comm").addClass( "hidden" );
						location.reload();        
					}
				});
			};
		}
				function viewpost(id)
		{
		    var identifier=id.value;
		    var auth = "";
		    $("#viewPost").modal('show');
		    $.ajax({
		        url:'posts/get_post', 
		        type:'POST',
		        data:{auth:auth,identifier:identifier}, 
		        success: function (result) {          
		          $("#post_view").html(result);
		        }
		     })  
		}
		function close_m(modal)
		{
		    var modal =modal.value;
		    $("#"+modal).modal('hide');
		}
		function like(identifier)
{
    var identifier=identifier.value;
    var auth="";
    if (identifier!='') {
    $.ajax({
        url:'posts/ls', 
        type:'POST',
        data:{auth:auth,identifier:identifier}, 
        success: function (result) {          
          if (result=='like_exist') {
            $.ajax({
                url:'posts/dl', 
                type:'POST',
                data:{auth:auth,identifier:identifier}, 
                success: function (result) {          
                  $("#likes_btn"+identifier).attr('style','margin-left:10px;background:none; border:none; float:left; color:#d9d9d9; font-size:1.3em;');
                  $.ajax({
                    url:'posts/lc', 
                    type:'POST',
                    data:{auth:auth,identifier:identifier}, 
                    success: function (result) {          
                      $("#likes"+identifier).html(result);
                    }
                 }) 
                }
             }) 
          };
          if (result=='liked') {
            $("#likes_btn"+identifier).attr('style','margin-left:10px;background:none; border:none; float:left; color:#cd0000; font-size:1.3em;');
            $.ajax({
                url:'posts/lc', 
                type:'POST',
                data:{auth:auth,identifier:identifier}, 
                success: function (result) {          
                  $("#likes"+identifier).html(result);
                }
             }) 
          };
        }
     })  
    };
}