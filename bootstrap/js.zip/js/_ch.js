$(document).ready(function () {    
    $(".main-cont").click(function(){        
        var div = $(this);
        div.scrollTop = div.scrollHeight;        
    })
});

function updateScroll(){
    var element = document.getElementById("top-container");
    element.scrollTop = element.scrollHeight;
}

(function($){

    $.fn.extend({ 

        addTemporaryClass: function(className, duration,cl) {
            var elements = this;
            setTimeout(function() {
                elements.fadeOut("slow"); 
                elements.attr('class','hide  chat-load-error popover');
            }, duration);

            return this.each(function() {                
                $(this).addClass(className);                                     
            });
        }
    });

})(jQuery);

$(document).ready(function () {  
	$(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')  
    $(".cover").each(function(){        
       $(this).click(function(){
       		if (online() > 0) {
        	$(".single-channel").hide()
       		var id = $(this).attr('id');
       		var to = '.main-channel';
       		 $(".main-channel").slideDown("slow")
       		$(".active").removeClass("active")
       		$("#"+id).addClass("active")
       		var loader = 'channel-loader';
       		if (id == 'chats') {
       			var url = 'user/fd';
       			var message = 'Received messages';
			}
			else if(id == 'net'){
				var url = 'user/fn';
				var message = 'People in your network';
			}
			else if(id == 'foll'){
				var url = 'user/fs';
				var message = 'People following you';
			}
			else{
				url = null;
				var message = 'error';
			}			
				get(id,url,to,loader,message);
			}
			else{
				$(".chat-load-error").html("No internet connection, attempting to connect...")
	 		    $(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
			}       		
       })
    })
});
 function get(id,url,to,loader,message){
 	if (url != null) {
    $(".close_chat_btn").attr('value','');    		
 		var test = '';
    clearInterval(r_mess);
 		$(".channel-loader").show()
 		$.ajax({
 			url:url,
 			type:'post',
 			data:{test:test},
 			success:function(response){
 				$(".channel-loader").hide()
 				$(to).html(response)
 				$(".chat-load-error").html(message)
 				$(".chat-load-error").addTemporaryClass('unhidden',5000)
 			},
 			error:function(response){
 				$(".channel-loader").hide()
 				$(".chat-load-error").html('An error occurred try again')
 				$(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
 			}
 		})
 	}
 }
 function read(id) {
        var id_=id.value;
        if (id_!='') {
        var auth="";  
        $("#cont_chat").html('');              
        $(".close_chat_btn").attr('value',id_);       
        $(".channel-loader").show()
        $(".main-channel").slideUp("slow")
        $(".single-channel").slideDown("slow") 
        if(online() > 0) {
        	$.ajax({
                url:'user/chat', 
                type:'POST',
                data:{uid:id_}, 
                success: function (result) {
                  $(".channel-loader").hide()
                  $("#cont_chat").html(result);                  
                  setInterval(r_mess, (5* 1000));                                             
                  $.ajax({
			            url:'messages/r', 
			            type:'POST',
			            data:{user:id_,auth:auth}, 
			            success: function (result) {
			              $("#m_count").html(result);
			              updateScroll()                                                                           
			            }
			         })                     
                },
                error:function(){
                	$(".chat-load-error").html('An error occurred try again')
                }
         })          
        }
        else{
        	$(".chat-load-error").html("No internet connection, attempting to connect...")
	 		$(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
        }     
        };
};

function send()
{
    var auth="";
    var message = $("input#search_box_pos").prop("value");    
    var to =$(".close_chat_btn").attr("value");   
    if (message!='') {
    	if(online() > 0){
        $('input#search_box_pos').val('');
        $.ajax({
            url:'messages/sm', 
            type:'POST',
            data:{message:message,to:to}, 
            success: function (result) {                
              $("#loader_chat").removeClass('hidden');
                $.ajax({
                    url:'user/chat', 
                    type:'POST',
                    data:{uid:to}, 
                    success: function (result) {
                      $("#loader_chat").addClass('hidden');
                      $("#cont_chat").html(result); 
                       updateScroll()                                                                              
                    }
                 })
            $.ajax({
                url:'messages/r', 
                type:'POST',
                data:{user:to,auth:auth}, 
                success: function (result) {
                  $("#m_count").html(result);
                }
             })             
            }
         })
       }
       else{
        	$(".chat-load-error").html("No internet connection, attempting to connect...")
	 		$(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
        }    
    };

}
function r_mess()
     {
     var auth="";  
     var id = $(".close_chat_btn").attr('value');       
      if (id !='' && online() > 0 ) {            
        $.ajax({
            url:'user/chat', 
            type:'POST',
            data:{uid:id}, 
            success: function (result) {                  
              $("#cont_chat").html(result);                  
              $.ajax({
                url:'messages/r', 
                type:'POST',
                data:{user:id,auth:auth}, 
                success: function (result) {
                  $("#m_count").html(result);                  
                }
             })  
            }
     })
	}
	else{
    	$(".chat-load-error").html("No internet connection, attempting to connect...")
 		  $(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
    } 
}
function close_chat(){    
    $("#chat_").fadeOut("slow"); 
    $("#cont_chat").html('');
    $("#close_chat").attr('value','');
    $("#loader_chat").removeClass('hidden');
    clearInterval(rmess);
};
$(document).ready(function () {
    $("#search_box_pos").on('keyup',function () {
        $("#search_box_pos").val($(this).val());
    });
});
$(document).ready(function () {
        $("input#search_box_pos").on('keypress',function (e) {
             if(e.which == 13) {
                send()                               
             }           
        });
});
function count_m()
{
    if (online() > 0) {      
    	if ($("#chats").hasClass("active")) {
    	var auth="";
	    $.ajax({
	        url:'messages/r1', 
	        type:'POST',
	        data:{auth:auth}, 
	        success: function (result) {
	          $("div#m_count").html(result);
	          if (result != '') {
	            $.ajax({
	                url:'messages/new_m', 
	                type:'POST',
	                data:{auth:auth}, 
	                success: function (result) {
	                  $(".main-channel").html(result)
	                }
	            })
	          };
	        }
	     })    
     }; 
    }else{
    	 $(".chat-load-error").html("No internet connection, attempting to connect...")
 		 $(".chat-load-error").addTemporaryClass('unhidden',5000,'chat-load-error')
    }
} 
count_m(); 
setInterval(count_m, (20* 1000));

function online(){
	var x = new (window.ActiveXObject || XMLHttpRequest)("Microsoft.XMLHTTP");
	var s;

	x.open("HEAD", "//" + window.location.hostname+ "/?" /*+ Math.floor((1 +Math.random())* 0x10000)*/,false);

	try{
		x.send()
		return x.status;
	}catch(error){
		return x.status;
	}
}

$(document).ready(function () {        
        $("#search_box").on('keyup',function () {
            var key = $(this).val();
            if (key.length==0) {
                $("#user_result").html('');
            };
            if (key.length>=3) {
              $(".sc").show()
              if (online() > 0) {
                $(".channel-loader").show();
                $.ajax({
                    url:$("#user_search_url").val(),
                    type:'GET',
                    data:'keyword='+key,
                    success:function (data) {
                        $("#user_result").html(data);
                        $("#user_result").slideDown('fast');
                        $(".channel-loader").hide();
                    }
                });
              }
              else{

              }
            };
        });
    });
$(document).ready(function(){
  $(".sc").on('click',function(){
    $("#search_box").val('')
    $(this).hide()
    $("#user_result").html('');
  })
})
function togglem(){

}