$(function(){
	var base = $(".main_url").val();
	var load = $(".loader-admin")
	var load_m = $(".main-loader")
	var layer = $(".overlay");	
	var l_cont = $(".o_main")
	$(".lgz-btn").click(function(){
		var l = $(".loader-l");
		var err = $(".text-danger");		
		err.html();
		var e = $('[type="email"]').val();
		var p = $('[type="password"]').val();
		if (e.replace(/\s/g, '').length < 4 || p.replace(/\s/g, '').length < 2) {			
			err.html("Enter valid email and password");
		}
		else{
			l.show();
			$.ajax({
				url:$(".main_url").val()+'admin/log',
				type:"POST",
				data:{e:e,p:p},
				success:function(data){
					l.hide();
					if (data.status == false) {
						err.html(data.m);
					}
					else{
						location.reload();
					}
				},
				error:function(){
					l.hide();
					err.html("An error occurred");
				}
			})
		}
	})
	$(".btn-go").click(function(){
		var n = $(".tn").val()
		var d = $(".tdr").val()
		if (n > 0) {
			load.show()
			$.ajax({
				url:base+"admin/anl",
				type:'POST',
				data:{n:n,d:d},
				success:function(data){
					load.hide()
					if (data.status == true) {
						$(".j-s").html(data.m)
					}
					else{
						alert("error");
					}
				},
				error:function(){
					load.hide()
					alert("error");
				}
			})
		}
	})
	$(".o_trigger").click(function(){
		var type = $(this).attr("type");
		var i = $(this).attr("value");
		if (i.replace(/\s/g, '').length > 0 && type.replace(/\s/g, '').length > 0) {
			layer.fadeIn("fast");
			load.show()
			$.ajax({
				url:base+"admin/u_g",
				method:"POST",
				data:{i:i,type:type},
				success:function(data){
					load.hide()
					if (data.status == true) {						
						if (type == 'v') {
							l_cont.append("<span style='font-size:1.9em;color:#000;'>"+i+", "+data.stats.geoplugin_countryName+"</span><hr style='border-color:#cd0000;margin:3px;'>")							
							l_cont.append(data.m)
						}
						else{
							l_cont.html(data.m)
						}
					}
					else{
						l_cont.html("<div style='text-align:center;font-size:2em;color:#cb0000;'>An error occurred</div>")
					}
				},
				error:function(){
					load.hide()
					l_cont.html("<div style='text-align:center;font-size:2em;color:#cb0000;'>An error occurred</div>")
				}
			})
		}
	})
	$(".close").click(function(){
		l_cont.html("")
		layer.fadeOut("fast");
	})
	$(".search-query").on('keyup',function () {
            var key = $(this).val();
            if (key.length==0) {
                $("#user_result").html('');
            };
            if (key.length>=3) {
            load.show();
            $.ajax({
                url:base+"user/search",
                type:'GET',
                data:'keyword='+key,
                success:function (data) {
                    load.hide();
                    if (data != 'error') {
                        $("#user_result").html(data);
                       $("#user_result").slideDown('fast');                   
                    }
                    else
                    {
                        alert("error")
                    }
                }
             });
            };
        });
})
function c_se(){
	$("#user_result").hide()
}